	<footer class="footer">
		<div class="container">
			<div class="footer-socials">
				<ul>
					<li>
						<a href="#" class="link-behance">behance</a>
					</li>
					
					<li>
						<a href="#" class="link-dribble">dribble</a>
					</li>
					
					<li>
						<a href="#" class="link-twitter">twitter</a>
					</li>
					
					<li>
						<a href="#" class="link-facebook">facebook</a>
					</li>
					
					<li>
						<a href="#" class="link-linkedin">linkedin</a>
					</li>
				</ul>
			</div><!-- /.footer-socials -->

			<p class="copyright">Copyright &copy; 2014 <a href="http://www.lucidsitedesigns.com/">Lucid</a> Onepage Theme</p><!-- /.copyright -->
		</div><!-- /.container -->
	</footer><!-- /.footer -->
</div><!-- /.wrapper -->
</body>
</html>
