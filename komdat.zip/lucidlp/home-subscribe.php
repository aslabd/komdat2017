<?php include('header.php'); ?>
		
		<div class="jumbotron">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<div class="jumbotron-content text-center">
							<h5>Introducing Lucid Theme</h5>
							
							<h1>Carefully crafted and beautiful landing page.</h1>
							
							<p>Etiam ullamcorper et turpis eget hendrerit. Praesent varius risus mi, at elementum magna ultricies acum magna ultricies accumsan. Cras venenatis lacus sed dolor placerat tempus. Morbi blandit at neque ut imperdiet.</p>
													
							<div class="subscribe">
								<form action="?" method="post">
									<label for="mail" class="hidden">Email</label>
									
									<input type="email" id="mail" name="mail" value="" placeholder="Your e-mail address" class="form-control form-control-subscribe">
									
									<input type="submit" value="Subscribe Now" class="btn btn-primary">
								</form>
							</div><!-- /.subscribe -->
						</div><!-- /.jumbotron-content -->
					</div><!-- /.col-md-6 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
		</div><!-- /.jumbotron -->
	</header><!-- /.header -->

<?php include('fragments/home-inner.php'); ?>
<?php include('footer.php'); ?>
